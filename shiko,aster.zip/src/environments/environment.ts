export const environment = {
  production: true,
  baseUrl: 'http://mohammedgalalfci-001-site1.etempurl.com/api/',
};
