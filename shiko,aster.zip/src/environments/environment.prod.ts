
export const environment = {
  production: false,
  baseUrl: 'http://mohammedgalalfci-001-site1.etempurl.com/api/',
};

