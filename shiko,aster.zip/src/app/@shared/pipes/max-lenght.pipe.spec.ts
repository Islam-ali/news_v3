import { MaxLenghtPipe } from './max-lenght.pipe';

describe('MaxLenghtPipe', () => {
  it('create an instance', () => {
    const pipe = new MaxLenghtPipe();
    expect(pipe).toBeTruthy();
  });
});
